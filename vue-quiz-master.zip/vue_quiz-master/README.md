# vue_quiz

Frontend VUEJS application for Quiz App. API is built in laravel and auth is done using laravel sanctum. Here's the backend https://github.com/AUAboi/quiz
