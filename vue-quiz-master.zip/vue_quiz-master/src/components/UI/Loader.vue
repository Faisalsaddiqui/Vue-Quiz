<template>
  <div class="popup z-50 text-white p-3 rounded-md">
    <img src="../../assets/Blocks-1s-200px.png" alt="loading" srcset="" />
  </div>
</template>

<style>
.popup {
  position: fixed;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>
