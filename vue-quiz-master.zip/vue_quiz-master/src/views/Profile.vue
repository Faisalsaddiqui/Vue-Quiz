<script setup>
import ScoreHistory from "@/components/ScoreHistory.vue";
</script>
<template>
  <h3 class="text-center my-8">View your user score history</h3>
  <ScoreHistory />
</template>
